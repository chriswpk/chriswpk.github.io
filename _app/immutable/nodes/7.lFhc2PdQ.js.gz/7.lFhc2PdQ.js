import"../chunks/DsnmJJEf.js";import"../chunks/XBAV1MCP.js";import{component as p}from"./12.LV5bDuka.js";function e(o){p(o,{})}export{e as component};
