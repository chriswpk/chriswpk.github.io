import"./DsnmJJEf.js";import{c as i,f as m,a as n}from"./ZrxNxfmJ.js";import{s as p}from"./BE6fgWX5.js";function c(r,o){var a=i(),t=m(a);p(t,()=>o.children),n(r,a)}export{c as L};
