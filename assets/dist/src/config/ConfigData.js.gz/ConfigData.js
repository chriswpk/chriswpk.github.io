export {};
//# sourceMappingURL=ConfigData.js.map